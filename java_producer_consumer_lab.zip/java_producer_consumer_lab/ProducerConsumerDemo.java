import java.util.LinkedList;
import java.util.Queue;

class PC {
    private final Queue<Integer> buffer = new LinkedList<>();
    private final int capacity;
    private int nextItem = 0;

    public PC(int capacity) {
        this.capacity = capacity;
    }

    public void produce() {
        while (!Thread.currentThread().isInterrupted()) {
            synchronized (this) {
                while (buffer.size() == capacity) {
                    try {
                        System.out.println("Buffer full. Producer is waiting...");
                        wait();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }

                int item = nextItem++;
                buffer.add(item);
                System.out.println("Producer produced-" + item);
                notify();
            }

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    public void consume() {
        while (!Thread.currentThread().isInterrupted()) {
            synchronized (this) {
                while (buffer.isEmpty()) {
                    try {
                        System.out.println("Buffer empty. Consumer is waiting...");
                        wait();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }

                int item = buffer.remove();
                System.out.println("Consumer consumed-" + item);
                notify();
            }

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }
}

public class ProducerConsumerDemo {
    public static void main(String[] args) {
        PC pc = new PC(2);

        Thread producer = new Thread(pc::produce, "Producer");
        Thread consumer = new Thread(pc::consume, "Consumer");

        producer.start();
        consumer.start();

        // Both threads run indefinitely. Stop the program with Ctrl+C.
    }
}
