# Java Producer-Consumer Lab

## Aim
Implement the Producer-Consumer problem in Java using a shared bounded buffer, `synchronized`, `wait()`, and `notify()`.

## Source file
- `ProducerConsumerDemo.java`

## Compile
```bash
javac ProducerConsumerDemo.java
```

## Run
```bash
java ProducerConsumerDemo
```

The shared buffer has capacity 2. The producer waits while the buffer is full, and the consumer waits while it is empty. Both threads run continuously until the program is stopped with Ctrl+C.

## Example output
Output order can vary because the threads run concurrently.

```text
Buffer empty. Consumer is waiting...
Producer produced-0
Consumer consumed-0
Producer produced-1
Consumer consumed-1
Producer produced-2
Consumer consumed-2
```
